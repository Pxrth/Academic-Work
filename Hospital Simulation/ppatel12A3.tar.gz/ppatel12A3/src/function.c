#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "HashTableAPI.h"
#include "function.h"



int hashNode(size_t tableSize, int key){

  return (key % tableSize);

}

void destroyNodeData(void *data){






}

void printNodeData(void *toBePrinted){




}
