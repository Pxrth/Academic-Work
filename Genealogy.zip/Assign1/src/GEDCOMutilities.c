#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>

#include "GEDCOMparser.h"
#include "GEDCOMutilities.h"


void *removeExtraSpace(char *string){

    int index = 0; 
    int i = 0;

    while(string[index] == '\t' || string[index] == '\n' || string[index] == ' ')  {
        index++;
    }

    if(index != 0){
        i = 0;
        while(string[i + index] != '\0'){
            string[i] = string[i + index];
            i++;
        }
        string[i] = '\0';
    }
    return string;
}

bool eventchecker(char *string){

    char * eventTags [] = { "ADOP", "BIRT", "BAPM", "BARM", "BASM", "BLES", "BURI",
    "CENS", "CHR" , "CHRA", "CONF", "CREM", "DEAT", "EMIG", "FCOM", "GRAD", "IMMI",
    "NATU", "ORDN", "RETI", "PROB", "WILL", "EVEN" , "MARR", "ANUL", "CENS", 
    "DIV", "DIVF", "ENGA", "MARB", "MARC", "MARL", "MARS", "EVEN"};

    int eventlen = sizeof(eventTags)/sizeof(eventTags[0]);

    for(int v = 0; v < eventlen; ++v){
        if(strcmp(string, eventTags[v]) == 0){ 
            return true;
        }
    }

    return false;
}

char *findValue(char *string){

    char *tempstring = malloc(sizeof(char)*255);

    strcpy(tempstring, "");

    if(string != NULL){
        strcat(tempstring, string);
    }


    return tempstring;
}

char *Pfgets(char *dst, int max, FILE *fp){
	int c;
    int a;
	char *p;
    long int pi = 0;

	for (p = dst, max--; max > 0; max--) {
		if ((c = fgetc (fp)) == EOF)
			break;
		*p++ = c;

        pi = ftell(fp);
        a = fgetc(fp);

        if(a == EOF){
            break;
        }

		if (c == '\r' && a != '\n'){
            fseek(fp, pi, SEEK_SET);
            break;
        }
        else if (c == '\n' && a != '\r'){
            fseek(fp, pi, SEEK_SET);
            break;
        }

        fseek(fp, pi, SEEK_SET);

	}
	*p = 0;
	if (p == dst || c == EOF)
		return NULL;
	return (p);
}