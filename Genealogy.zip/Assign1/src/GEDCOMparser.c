#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>

#include "GEDCOMparser.h"
#include "GEDCOMutilities.h"
#include "LinkedListAPI.h"

//******************************   DECLARATIONS   ******************************//

GEDCOMerror head_Parser(char** array, int *counter, GEDCOMobject* object);
GEDCOMerror headerValidation(char** array, int *counter, int *flag, GEDCOMobject** obj);

GEDCOMerror individual_Parser(char** array, int *counter, GEDCOMobject* object, Individual *indidata);
GEDCOMerror individualValidation(char** array, int *counter, int *indiflag, GEDCOMobject **obj);

GEDCOMerror family_Parser(char** array, int *counter, GEDCOMobject* object, Family *famdata, Xlist *list);
GEDCOMerror familyValidation(char** array, int *counter, int *famflag, GEDCOMobject **obj);

GEDCOMerror submitter_Parser(char* array[], int *counter, GEDCOMobject* object);
GEDCOMerror submitterValidation(char** array, int *counter, int *subflag, GEDCOMobject **obj);

GEDCOMerror main_Parser(char* fileName, GEDCOMobject** obj);

List descendants(const GEDCOMobject* familyRecord, const Individual* person, List *list);

//******************************   GEDCOM OBJECT FUNCTIONS   ******************************//

GEDCOMerror createGEDCOM(char* fileName, GEDCOMobject** obj){

    int zeroflag = 0;
    int headflag = 0;
    int tailflag = 0;
    int subflag = 0;
    
    GEDCOMerror okay;
    okay.type = (ErrorCode)OK;
    okay.line = -1;

    GEDCOMerror fileerror;
    fileerror.type = (ErrorCode)INV_FILE;
    fileerror.line = -1;

    GEDCOMerror invalidheader;
    invalidheader.type = (ErrorCode)INV_HEADER;
    invalidheader.line = 1;
    
    GEDCOMerror gedcomerror;
    gedcomerror.type = (ErrorCode)INV_GEDCOM;
    gedcomerror.line = -1;


    if(fileName == NULL || strlen(fileName) == 0){
        char * str = printError(fileerror);
        puts(str);
        return fileerror;
    }
    else{
        if(strstr(fileName, ".ged") == NULL){
            char * str = printError(fileerror);
            puts(str);
            return fileerror; 
        }
        else{
            FILE *fptr;
            fptr = fopen(fileName, "r");

            if(fptr == NULL){
                char * str = printError(fileerror);
                puts(str);
                return fileerror;
            }
            else{
                char **array2 = malloc(sizeof(char*)*1000000);
                char line[1000];
                int *check = malloc(sizeof(int));
                *check = 0;
                int count = 0;
                FILE *fptr;
                fptr = fopen(fileName, "r");
                while(Pfgets(line, 300, fptr) != NULL){

                    line[strcspn(line, "\r\n")] = '\0';

                    array2[*check] = (char*)malloc(sizeof(char)*1000);
                    removeExtraSpace(line);
                    strcpy(array2[*check], line);
                    

                    (*check)++;
                    count++;
                }
                fclose(fptr);

                *check = 0;
                char *string = malloc(sizeof(char)*1000);
                strcpy(string, array2[*check]);
                char *p = strtok(string, " ");
                
                if(strcmp(p, "0") == 0){
                    zeroflag = 1;
                    p = strtok(NULL, " ");
                        if(strcmp(p, "HEAD") == 0){
                            headflag = 1;
                        }
                }

                *check = count-1;
                strcpy(string, array2[*check]);
                char *pa = strtok(string, " ");
                if(strcmp(pa, "0") == 0){
                    pa = strtok(NULL, " ");
                        if(strcmp(pa, "TRLR") == 0){
                            tailflag = 1;
                        }
                }
                
                char *string2 = malloc(sizeof(char)*10000);
                for(*check = 0; *check < count; (*check) = (*check) + 1) {
                    strcpy(string2, array2[*check]);
                    char *par = strtok(string2, " ");
                    par = strtok(NULL, " ");
                    par = strtok(NULL, " ");
                    if(par != NULL){
                        if(strcmp(par, "SUBM") == 0){
                            subflag = 1;
                        }
                    }
                }

                if(tailflag == 1 && headflag == 1 && subflag == 1){
                    return main_Parser(fileName, obj);
                }
                
                if(zeroflag != 1){
                    obj = NULL;
                    return invalidheader;
                }
                if(subflag != 1){
                    obj = NULL;
                    return gedcomerror;
                }
                if(headflag != 1){
                    obj = NULL;
                    return gedcomerror;
                }
                if(tailflag != 1){
                    obj = NULL;
                    return gedcomerror;
                }
            }
            fclose(fptr);
        }
    }

    return okay;
}


char* printGEDCOM(const GEDCOMobject* obj){


    if(obj != NULL){  

        char *string = malloc(sizeof(char)* 10000);
        strcpy(string, toString(obj->individuals));

        return string;

    }
    else{
        return NULL;
    }


/*
    printf("-----Header-----\n");
    printf("source %s || version %lf || char %d || SubmitterName %s||\n", obj->header->source, obj->header->gedcVersion, obj->header->encoding, obj->header->submitter->submitterName);

    Node* indi = obj->individuals.head;
                
    while(indi != NULL){
         printf("-----Individual-----\n");
         printf("GivenName:%s|| SurName:%s||\n",((Individual*)indi->data)->givenName, ((Individual*)indi->data)->surname);
        
         Node* event = ((Individual*)indi->data)->events.head;
         printf("-----Events-----\n");
         while(event != NULL){
            
             printf("Type: %s || Date: %s || Place: %s||\n", ((Event*)event->data)->type, ((Event*)event->data)->date, ((Event*)event->data)->place);

             event = event->next;
         }

         Node* other = ((Individual*)indi->data)->otherFields.head;
         printf("-----OthersField-----\n");

         while(other != NULL){

             printf("Tag: %s || Value: %s||\n", ((Field*)other->data)->tag, ((Field*)other->data)->value);

             other = other->next;
         }

         indi = indi->next;
     }

     Node* fam = obj->families.head;

     while(fam != NULL){

         printf("-----Family-----\n");

         printf("HUSBAND\n");
		 printf("GivenName:%s|| SurName:%s||\n", ((Family*)fam->data)->husband->givenName, ((Family*)fam->data)->husband->surname);

         printf("WIFE\n");
         printf("GivenName:%s|| SurName:%s||\n", ((Family*)fam->data)->wife->givenName, ((Family*)fam->data)->wife->surname);
        
         Node* child = ((Family*)fam->data)->children.head;
         printf("CHILDRED\n");

         while(child != NULL){

             printf("GivenName:%s|| SurName:%s||\n", ((Individual*)child->data)->givenName, ((Individual*)child->data)->surname);

             child = child->next;
         }

         Node* event = ((Family*)fam->data)->events.head;
         printf("-----Events-----\n");
         while(event != NULL){
             printf("Type: %s || Date: %s || Place: %s||\n", ((Event*)event->data)->type, ((Event*)event->data)->date, ((Event*)event->data)->place);

             event = event->next;
         }

         Node* other = ((Family*)fam->data)->otherFields.head;
         printf("-----OthersField-----\n");
         while(other != NULL){

             printf("Tag: %s || Value: %s||\n", ((Field*)other->data)->tag, ((Field*)other->data)->value);

             other = other->next;
         }


         fam = fam->next;
     }

     return NULL;

*/     

}


void deleteGEDCOM(GEDCOMobject* obj){

/*
    if(obj != NULL){
        //make delete header function or write code here
        free(obj->header);
        clearList(&(obj->families));
        clearList(&(obj->individuals));
        free(obj->submitter);
        //make delete submitter function or write code here
    }
    else{
        return;
    }

    obj->header = NULL;
    obj->submitter = NULL;

*/
}


char* printError(GEDCOMerror err){

    char *string = (char*)malloc(sizeof(char)*200);

    if(err.type == OK){
        strcpy(string, "OK");
        return string;
    }
    else if(err.type == INV_FILE){
        strcpy(string, "Invalid File");
        return string;
    }
    else if(err.type == INV_GEDCOM){
        strcpy(string, "Invalid GEDCOM Object");
        return string;
    }
    else if(err.type == INV_HEADER){
        strcpy(string, "Invalid Header");
        return string;
    }
    else if(err.type == INV_RECORD){
        strcpy(string, "Invalid Record");
        return string;
    }
    else{
        strcpy(string, "Other Error");
        return string;
    }

    //free(string);
}


Individual* findPerson(const GEDCOMobject* familyRecord, bool (*compare)(const void* first, const void* second), const void* person){

    if(familyRecord != NULL){

        return ((Individual*)findElement(familyRecord->individuals, compare, person));

    }
    else{
        return NULL;
    }

}


List getDescendants(const GEDCOMobject* familyRecord, const Individual* person){


    List list2 = initializeList(&printIndividual, &deleteIndividual, &compareIndividuals);


    if(familyRecord != NULL && person != NULL){

        descendants(familyRecord, person, &list2);

        return list2;

    }

    return list2;

}


List descendants(const GEDCOMobject* familyRecord, const Individual* person, List *list){

    if(person == NULL){
        return *list;
    }


    Node *fam = person->families.head;

    while(fam != NULL){

        if(person == ((Family*)fam->data)->husband || person == ((Family*)fam->data)->wife){

            Node *child = ((Family*)fam->data)->children.head;

            while(child != NULL){
                
                insertBack(list, ((Individual*)child->data));
                *list = descendants(familyRecord, ((Individual*)child->data), list);

                child = child->next;
    
            }

        }

        fam = fam->next;
    }

    return *list;

}

//******************************   END OF GEDCOM OBJECT FUNCTIONS   ******************************//



//******************************   HELPER FUNCTIONS   ******************************//


void deleteEvent(void* toBeDeleted){

/*
    Event *del = malloc(sizeof(Event));

    if(toBeDeleted != NULL){
        del = toBeDeleted;
        free(del->date);
        free(del->place);
        clearList(&(del->otherFields));
        free(del);
    }
 */
}


int compareEvents(const void* first,const void* second){


    return 0;
}


char* printEvent(void* toBePrinted){

    Event* eventprint = (Event*)toBePrinted;


    if(toBePrinted != NULL){

        char *string = malloc(sizeof(char)* (strlen(eventprint->type) + strlen(eventprint->date) + strlen(eventprint->place) + 500));

        sprintf(string, "Event:%s Date:%s Place:%s\n", eventprint->type, eventprint->date, eventprint->place);

        return string;
        
    }
    else{
        // char* dummyString = calloc(1, sizeof(char)*256);
        // strcpy(dummyString, "");
        // return dummyString;
        return NULL;
    }
}


void deleteIndividual(void* toBeDeleted){

/*
    Individual *delindi = malloc(sizeof(Individual));

    if(toBeDeleted != NULL){
        delindi = toBeDeleted;
        free(delindi->givenName);
        free(delindi->surname);
        clearList(&(delindi->events));
        clearList(&(delindi->families));
        clearList(&(delindi->otherFields));
        free(delindi);
    }
 */
}


int compareIndividuals(const void* first,const void* second){


    return 0;

}


char* printIndividual(void* toBePrinted){

    Individual *indiprint = (Individual*)toBePrinted;
    
    if(toBePrinted != NULL){
        char *string = malloc(sizeof(char)* (strlen(indiprint->givenName) + strlen(indiprint->surname) + 500));

        sprintf(string, "Given:%s Surname:%s\n", indiprint->givenName, indiprint->surname);
        strcat(string, toString(indiprint->events));
        strcat(string, toString(indiprint->otherFields));
        
        return string;
    }
    else{
        return NULL;
    }

}


void deleteFamily(void* toBeDeleted){
	
	/*

    Family *delfam = malloc(sizeof(Family));

    if(toBeDeleted != NULL){
        delfam = toBeDeleted;
        free(delfam->wife);
        free(delfam->husband);
        clearList(&(delfam->children));
        clearList(&(delfam->otherFields));
        free(delfam);
    }
    * 
    */

}


int compareFamilies(const void* first,const void* second){


    return 0;
}


char* printFamily(void* toBePrinted){

    Family *famprint = (Family*)toBePrinted;

    
    if(toBePrinted != NULL){

        char *string = malloc(sizeof(char)* 10000);

        sprintf(string, "Husband:%s %s Wife:%s %s\n", famprint->husband->givenName, famprint->husband->surname, famprint->wife->givenName, famprint->wife->surname);
        strcpy(string, toString(famprint->children));
        strcat(string, toString(famprint->events));
        strcat(string, toString(famprint->otherFields));
        

        //free(famprint);
        return string;
    }
    else{
        return NULL;
    }

}


void deleteField(void* toBeDeleted){

/*
    Field *delfield = malloc(sizeof(Field));

    if(toBeDeleted != NULL){
        delfield = toBeDeleted;
        free(delfield->tag);
        free(delfield->value);
        free(delfield);
    }
    * 
*/
}


int compareFields(const void* first,const void* second){


    return 0;

}


char* printField(void* toBePrinted){

    Field *fieldprint = (Field*)toBePrinted;

    if(toBePrinted != NULL){
        char *string = malloc(sizeof(char)* strlen(fieldprint->tag) + strlen(fieldprint->value) + 500);
        sprintf(string, "Tag:%s Value:%s\n", fieldprint->tag, fieldprint->value);

        return string;
        
    }
    else{
        // char* dummyString = calloc(1, sizeof(char)*256);
        // strcpy(dummyString, "");
        // return dummyString;

        return NULL;
    }

}


//******************************   END OF HELPER FUNCTIONS   ******************************//



//******************************   PARSER FUNCTIONS START  ******************************//

Submitter *create_Submitter(){

    Submitter *Subinfo = malloc(sizeof(Submitter) + sizeof(char[256])) ;

	
    strcpy(Subinfo->submitterName, "Submitter");
    strcpy(Subinfo->address, " ");
    Subinfo->otherFields = initializeList(printField, deleteField, compareFields);

    return Subinfo;
}

Event *create_Event(){

    Event *Eventinfo = malloc(sizeof(Event));
	
	Eventinfo->date = malloc(1000);
	Eventinfo->place = malloc(1000);
	
	strcpy(Eventinfo->date, " ");
	strcpy(Eventinfo->place, " ");
	
    Eventinfo->otherFields = initializeList(printEvent, deleteEvent, compareEvents);

    return Eventinfo;
}

Header *create_Header(){

    Header *Headinfo = malloc(sizeof(Header) + sizeof(char[256]));
	
    strcpy(Headinfo->source, "PAF");
    Headinfo->gedcVersion = 0.0;
    Headinfo->encoding = ASCII;
    Headinfo->submitter = NULL;
    Headinfo->otherFields = initializeList(printField, deleteField, compareFields);

  return Headinfo;
}

Individual *create_Individual(){

    Individual *Indivinfo = malloc(sizeof(Individual));
	
	Indivinfo->givenName = malloc(1000);
	Indivinfo->surname = malloc(1000);
	
	strcpy(Indivinfo->givenName, " ");
	strcpy(Indivinfo->surname, " ");

    Indivinfo->events = initializeList(printEvent, deleteEvent, compareEvents);
    Indivinfo->families = initializeList(printFamily, deleteFamily, compareFamilies);
    Indivinfo->otherFields = initializeList(printField, deleteField, compareFields);
    
    return Indivinfo;
}

Family *create_Family(){

    Family *Faminfo = malloc(sizeof(Family));

    Faminfo->wife = NULL;
    Faminfo->husband = NULL;
    Faminfo->children = initializeList(printIndividual, deleteIndividual, compareIndividuals);
    Faminfo->events = initializeList(printEvent, deleteEvent, compareEvents);
    Faminfo->otherFields = initializeList(printField, deleteField, compareFields);

    return Faminfo;
}

Field *create_Field(){

    Field *fieldinfo = malloc(sizeof(Field));
	
	fieldinfo->tag = malloc(1000);
	fieldinfo->value = malloc(1000);
	
	strcpy(fieldinfo->tag, " ");
	strcpy(fieldinfo->value, " ");

    return fieldinfo;
}

GEDCOMobject *create_Obj(){

    GEDCOMobject *obj = malloc(sizeof(GEDCOMobject));

    obj->header = create_Header();
    obj->families = initializeList(printFamily, deleteFamily, compareFamilies);
    obj->individuals = initializeList(printIndividual, deleteIndividual, compareIndividuals);
    obj->submitter = create_Submitter();
    
    return obj;
}


// ************************************** LIST ************************************** //

Indixref *createIXref(){

    Indixref *indi = malloc(sizeof(Indixref));

	indi->ref = malloc(1000);
	
	strcpy(indi->ref, " ");
	
    return indi;
}

Famxref *createFXref(){

    Famxref *fam = malloc(sizeof(Famxref));
    
    fam->tag = malloc(1000);
    fam->ref = malloc(1000);
  
    
    strcpy(fam->tag, " ");
    strcpy(fam->ref, " ");


    return fam;
}

Xlist *createXlist(){

    Xlist *list = malloc(sizeof(Xlist));


    list->Ixlist = initializeList(printIndividual, deleteIndividual, compareIndividuals);
    list->Fxlist = initializeList(printIndividual, deleteIndividual, compareIndividuals);


    return list;

}


GEDCOMerror main_Parser(char* fileName, GEDCOMobject** obj){

    GEDCOMobject *object = create_Obj();
    Xlist * list = createXlist();

    GEDCOMerror okay;
    okay.type = (ErrorCode)OK;
    okay.line = -1;

    GEDCOMerror invalidrecord;
    invalidrecord.type = (ErrorCode)INV_RECORD;
    invalidrecord.line = -1;

    char **array = malloc(sizeof(char*)*1000000);
    char line[1000];

    int *h = malloc(sizeof(int));
    *h = 0;
    int *k = malloc(sizeof(int));
    *k = 0;
    int *i = malloc(sizeof(int));
    *i = 0;
    int *flag = malloc(sizeof(int));
    *flag = 0;
    int *indiflag = malloc(sizeof(int));
    *indiflag = 0;
    int *famflag = malloc(sizeof(int));
    *famflag = 0;
    int *subflag = malloc(sizeof(int));
    *subflag = 0;
    int count = 0;

    int temp;
    FILE *fptr;
    fptr = fopen(fileName, "r");

    while(Pfgets(line, 260, fptr) != NULL){
		
		if(line != NULL){
			
			temp = strlen(line);
			if(temp >= 255){
				count++;
				*obj = NULL;
				obj = NULL;
				invalidrecord.line = count;
				return invalidrecord;
			}
			else{

				line[strcspn(line, "\r\n")] = '\0';

				array[*i] = (char*)malloc(sizeof(char)*1000);
				removeExtraSpace(line);
				strcpy(array[*i], line);

				(*i)++;
				count++;
			}
		}
    }
    
    fclose(fptr);

    char *string = malloc(sizeof(char)*255);

    for(*i = 0; *i < count; (*i) = (*i) + 1) {
        strcpy(string, array[*i]);
        char *p = strtok(string, " ");

        while(p != NULL){
            if(strcmp(p, "HEAD") == 0){
                *k = (*k) + 1;
                headerValidation(array, k, flag, obj);
                if(*flag == 1){
                    *i = (*i) + 1;
                    head_Parser(array, i, object);
                }
                else if(*flag == 2){
                    *k = 1;
                    return headerValidation(array, k, flag, obj);
                }
            }
            else if(strcmp(p, "INDI") == 0){
				strcpy(string, array[*i]);
				char *p = strtok(string, " ");
				p = strtok(NULL, " ");
				
                Individual *indidata = create_Individual();
                Indixref *indi = createIXref();

                strcpy(indi->ref, p);
                indi->indi = indidata;

                insertBack(&list->Ixlist, indi);
                
                *k = (*k) + 1;
                *h = *k;
                individualValidation(array, k, indiflag, obj);
                if(*indiflag == 1){
                    *i = (*i) + 1;
                    individual_Parser(array, i, object, indidata);
                }
                else if(*indiflag == 2){
                    *k = *h;
                    return individualValidation(array, k, indiflag, obj);
                }
            }
            else if(strcmp(p, "FAM") == 0){

				//printf("Family created: %s\n", p);
                Family *famdata = create_Family();

                *k = (*k) + 1;
                *h = *k;
                familyValidation(array, k, famflag, obj);
                if(*famflag == 1){
                    *i = (*i) + 1;
                    family_Parser(array, i, object, famdata, list);
                }
                else if(*famflag == 2){
                    *k = *h;
                    return familyValidation(array, k, famflag, obj);
                }
            }
            else if(strcmp(p, "SUBM") == 0){
                *k = (*k) + 1;
                *h = *k;
                submitterValidation(array, k, subflag, obj);
                if(*subflag == 1){
                    *i = (*i) + 1;
                    submitter_Parser(array, i, object);
                }
                else if(*subflag == 2){
                    *k = *h;
                    return submitterValidation(array, k, subflag, obj);
                }
            }
            else if(strcmp(p, "TRLR") == 0){

                Node* temp = list->Ixlist.head;
                Node* temp2 = list->Fxlist.head;

                

                while(temp2 != NULL){
                    temp = list->Ixlist.head;
                    while(temp != NULL){   
                        
                        if(strcmp(((Indixref*)temp->data)->ref, ((Famxref*)temp2->data)->ref) == 0){
                            if(strcmp(((Famxref*)temp2->data)->tag, "HUSB") == 0){
                                ((Famxref*)temp2->data)->fam->husband = ((Indixref*)temp->data)->indi;
                                insertBack(&((Indixref*)temp->data)->indi->families, ((Famxref*)temp2->data)->fam);
                            }  
                            else if(strcmp(((Famxref*)temp2->data)->tag, "WIFE") == 0){
                                ((Famxref*)temp2->data)->fam->wife = ((Indixref*)temp->data)->indi;
                                insertBack(&((Indixref*)temp->data)->indi->families, ((Famxref*)temp2->data)->fam);
                            }
                            else if(strcmp(((Famxref*)temp2->data)->tag, "CHIL") == 0){
                                insertBack(&((Famxref*)temp2->data)->fam->children, ((Indixref*)temp->data)->indi);
                                insertBack(&((Indixref*)temp->data)->indi->families, ((Famxref*)temp2->data)->fam);
    
                            }
                        }

                        temp = temp->next;
                    }
                    temp2 = temp2->next;
                }

                *obj = object;
                return okay;
            }
            p = strtok(NULL, " ");
        }
        (*k) = (*k) + 1;
    }

    return okay;
}


GEDCOMerror headerValidation(char** array, int *counter, int *flag, GEDCOMobject **obj){

    GEDCOMerror okay;
    okay.type = (ErrorCode)OK;
    okay.line = -1;

    GEDCOMerror invalidheader;
    invalidheader.type = (ErrorCode)INV_HEADER;
    invalidheader.line = *counter;

    GEDCOMerror invalidrecord;
    invalidrecord.type = (ErrorCode)INV_RECORD;
    invalidrecord.line = -1;

    int prevlvl = 0;
    int currlvl = 0;

    int x = 0, y = 0, z = 0, a = 0;
    char *string = malloc(sizeof(char)*255);

    while(array[*counter][0] != '0'){

        strcpy(string, array[*counter]);
        char *p = strtok(string, " ");
        
        prevlvl = currlvl;
        currlvl = atoi(p);  

        if((currlvl == (prevlvl + 1) || currlvl == prevlvl || currlvl == (prevlvl - 1)) && (currlvl < 99)){
            
            p = strtok(NULL, " ");

            if(strcmp(p, "SOUR") == 0){
                x = 1;
                p = strtok(NULL, " ");
                if(p == NULL){
                    *flag = 2;
                    (*counter)++;
                    *obj = NULL;
                    obj = NULL;
                    return invalidheader;
                }
            }
            else if(strcmp(p, "GEDC") == 0){
                z = 1;
                (*counter)++;
                strcpy(string, array[*counter]);
                char *p = strtok(string, " ");

                prevlvl = currlvl;
                currlvl = atoi(p); 

                if((currlvl == (prevlvl + 1) || currlvl == prevlvl || currlvl == (prevlvl - 1)) && (currlvl < 99)){
                    p = strtok(NULL, " ");
                    if(strcmp(p, "VERS") != 0){
                        *flag = 2;
                        (*counter)++;
                        *obj = NULL;
                        obj = NULL;
                        return invalidheader;
                    }
                    else if(strcmp(p, "VERS") == 0){
                        p = strtok(NULL, " ");
                        if(p == NULL){
                            *flag = 2;
                            (*counter)++;
                            *obj = NULL;
                            obj = NULL;
                            return invalidheader;
                        }
                    }
                }
                else{
                    *flag = 2;
                    (*counter)++;
                    *obj = NULL;
                    obj = NULL;
                    invalidrecord.line = *counter;
                    return invalidrecord;
                }
            }
            else if(strcmp(p, "CHAR") == 0){
                y = 1;
                p = strtok(NULL, " ");
                if(p == NULL){
                    *flag = 2;
                    (*counter)++;
                    *obj = NULL;
                    obj = NULL;
                    return invalidheader;
                }
            }
            else if(strcmp(p, "SUBM") == 0){
                a = 1;
                p = strtok(NULL, " ");
                if(p == NULL){
                    *flag = 2;
                    (*counter)++;
                    *obj = NULL;
                    obj = NULL;
                    return invalidheader;
                }
            }
        }
        else{   
            *flag = 2;
            (*counter)++;
            *obj = NULL;
            obj = NULL;
            invalidrecord.line = *counter;
            return invalidrecord;
        }
        (*counter)++;
    }

    if(x != 1 || y != 1 || z != 1 || a != 1){
        *flag = 2;
        *obj = NULL;
        obj = NULL;
        return invalidheader;
    }

    (*counter)--;
    *flag = 1;
    return okay;
}


GEDCOMerror head_Parser(char** array, int *counter, GEDCOMobject* object){

    GEDCOMerror okay;
    okay.type = (ErrorCode)OK;
    okay.line = -1;

    Field *fielddata = create_Field();

    char *string = malloc(sizeof(char)*255);

    while(array[*counter][0] != '0'){

        strcpy(string, array[*counter]);
        char *p = strtok(string, " ");
        p = strtok(NULL, " ");

        while(p != NULL){
            if(strcmp(p, "SOUR") == 0){
                p = strtok(NULL, " ");
                strcpy(object->header->source, findValue(p));
                //printf("The source information is: %s\n", object->header->source);
            }
            else if(strcmp(p, "GEDC") == 0){
                (*counter)++;
                strcpy(string, array[*counter]);
                char *p = strtok(string, " ");
                p = strtok(NULL, " ");
                if(strcmp(p, "VERS") == 0){
                    p = strtok(NULL, " ");
                    float version = atof(p);
                    object->header->gedcVersion = version;
                    //printf("The GEDC version is: %.1f\n", object->header->gedcVersion);
                }
            }
            else if(strcmp(p, "CHAR") == 0){
                p = strtok(NULL, " ");
                if(strcmp(p, "ANSEL") == 0){
                    object->header->encoding = ANSEL;
                }
                else if(strcmp(p, "UTF-8") == 0){
                    object->header->encoding = UTF8;
                }
                else if(strcmp(p, "UNICODE") == 0){
                    object->header->encoding = UNICODE;
                }
                else if(strcmp(p, "ASCII") == 0){
                    object->header->encoding = ASCII;
                }
                //printf("The encoding is: %u\n", object->header->encoding);
            }
            else if(strcmp(p, "SUBM") == 0){
                object->header->submitter = create_Submitter(); 
                //p = strtok(NULL, " ");
                //char *subadd = malloc(sizeof(char*)*50);
                //strcpy(subadd, p);
                //strcpy(object->header->submitter->address, subadd);
                //printf("Submitter Address is %s\n", object->header->submitter->address);
            }
            else{
                fielddata = create_Field();
                insertBack(&object->header->otherFields, fielddata);
                ((Field*)getFromBack(object->header->otherFields))->tag = p;
                char * value = malloc(sizeof(char*)*50);
                p = strtok(NULL, " ");
				
				strcpy(value, " ");
                while(p != NULL){
					strcat(value, " ");
                    strcat(value, p);
                    p = strtok(NULL, " ");
                }
                
                removeExtraSpace(value);

                ((Field*)getFromBack(object->header->otherFields))->value = value;
                //printf("Tag: %s and Value: %s\n", ((Field*)getFromBack((object->header->otherFields)))->tag, ((Field*)getFromBack((object->header->otherFields)))->value);
            }
            p = strtok(NULL, " ");
        }
        (*counter)++;
    }

    (*counter)--;
    return okay;
}


GEDCOMerror individualValidation(char** array, int *counter, int *indiflag, GEDCOMobject **obj){

    GEDCOMerror okay;
    okay.type = (ErrorCode)OK;
    okay.line = -1;

    GEDCOMerror invalidrecord;
    invalidrecord.type = (ErrorCode)INV_RECORD;
    invalidrecord.line = -1;

    int prevlvl = 1;
    int currlvl = 1;
    char *string = malloc(sizeof(char)*255);

    while(array[*counter][0] != '0'){

        strcpy(string, array[*counter]);
        char *p = strtok(string, " ");
        
        prevlvl = currlvl;
        currlvl = atoi(p);
        
        if((currlvl == (prevlvl + 1) || currlvl == prevlvl || currlvl == (prevlvl - 1)) && (currlvl < 99)){
            
        }
        else{   
            *indiflag = 2;
            (*counter)++;
            *obj = NULL;
            obj = NULL;
            invalidrecord.line = *counter;
            return invalidrecord;
        }

        (*counter)++;
    }

    (*counter)--;

    *indiflag = 1;
    return okay;

}


GEDCOMerror individual_Parser(char** array, int *counter, GEDCOMobject* object, Individual *indidata){
    
    GEDCOMerror okay;
    okay.type = (ErrorCode)OK;
    okay.line = -1;

    Event *eventdata;
    Field *fielddata;
    
    int flag = 0;

    char * eventTags [] = { "ADOP", "BIRT", "BAPM", "BARM", "BASM", "BLES", "BURI",
    "CENS", "CHR" , "CHRA", "CONF", "CREM", "DEAT", "EMIG", "FCOM", "GRAD", "IMMI",
    "NATU", "ORDN", "RETI", "PROB", "WILL", "EVEN" , "MARR", "ANUL", "CENS", 
    "DIV", "DIVF", "ENGA", "MARB", "MARC", "MARL", "MARS", "EVEN"};

    int eventlen = sizeof(eventTags)/sizeof(eventTags[0]);

    char *string = malloc(sizeof(char)*255);
    while(array[*counter][0] != '0'){
        
        strcpy(string, array[*counter]);
        char *p = strtok(string, " ");
        p = strtok(NULL, " ");

        while(p != NULL){
            if(eventchecker(p) == true){
                for(int v = 0; v < eventlen; ++v){
                    if(strcmp(p, eventTags[v]) == 0){ 
                        eventdata = create_Event();
                        insertBack(&indidata->events, eventdata);
                        strcpy(((Event*)getFromBack(indidata->events))->type, p);
                        //printf("Event Tag: ||%s||\n", ((Event*)getFromBack(indidata->events))->type);
                    }
                }
                (*counter)++;
                while(array[*counter][0] != '1'){
                    strcpy(string, array[*counter]);
                    char *p = strtok(string, " ");
                    p = strtok(NULL, " ");

                    while(p != NULL){
                        if(strcmp(p, "DATE") == 0){
                            p = strtok(NULL, " ");
                            char * date = (char *) malloc(sizeof(char) * 100);
                            
                            strcpy(date, " ");
                            while(p != NULL){
								strcat(date, " ");
                                strcat(date, p);
                                p = strtok(NULL, " ");
                            }
                            
                 
                            removeExtraSpace(date);

                            ((Event*)getFromBack(indidata->events))->date = date;
                            //printf("Date: %s\n", ((Event*)getFromBack(indidata->events))->date);
                        }
                        else if(strcmp(p, "PLAC") == 0){
                            p = strtok(NULL, " ");
                            char * place = (char *) malloc(sizeof(char) * 100);
                            
                            strcpy(place, " ");
                            while(p != NULL){
                                strcat(place, " ");
                                strcat(place, p);
                                p = strtok(NULL, " ");
                            }

                            removeExtraSpace(place);

                            ((Event*)getFromBack(indidata->events))->place = place;
                            //printf("Place: %s\n", ((Event*)getFromBack(indidata->events))->place);
                        }
                        else{
                            fielddata = create_Field();
                            insertBack(&eventdata->otherFields, fielddata);
                            ((Field*)getFromBack(eventdata->otherFields))->tag = p;
                            char * value = malloc(sizeof(char*)*50);
                            p = strtok(NULL, " ");

							strcpy(value, " ");
                            while(p != NULL){
								strcat(value, " ");
                                strcat(value, p);
                                p = strtok(NULL, " ");
                            }
                            
                            removeExtraSpace(value);

                            ((Field*)getFromBack(eventdata->otherFields))->value = value;
                        }
                        p = strtok(NULL, " ");
                    }
                    (*counter)++;
                }
                (*counter)--;
            }
            else{
                if(strcmp(p, "FAMC") == 0 || strcmp(p, "FAMS") == 0){
                    p = strtok(NULL, " ");
                }
                else if(strcmp(p, "GIVN") == 0 || strcmp(p, "SURN") == 0){
					p = strtok(NULL, " ");
				}
                else if(strcmp(p, "NAME") == 0){
                    p = strtok(NULL, " /");
                    indidata->givenName = malloc(sizeof(char) * 40);
                    indidata->surname = malloc(sizeof(char) * 40);
					
					if(strcmp(p, "Unknown") == 0){
						strcpy(indidata->givenName, p);
						strcpy(indidata->surname, p);
						flag = 1;
					}
					
					
					if(flag == 0){
						if(strcmp(p, " ") == 0){
							strcpy(indidata->givenName, " ");
						}
						else{
							strcpy(indidata->givenName, p);
						}

						if(strcmp(p, "Not") == 0){
							strcpy(indidata->givenName, p);
							strcat(indidata->givenName, " ");
							p = strtok(NULL, " ");
							strcat(indidata->givenName, p);
						}
					}
				
					
					p = strtok(NULL, "/");
					
					if(flag == 0){
						if(p == NULL){
							strcpy(indidata->surname, " ");
						}
						else{
							indidata->surname = malloc(sizeof(char) * 40);

							while(p != NULL){
								strcpy(indidata->surname, p);
								p = strtok(NULL, " ");
							}
						}
					}
				
            

                     //printf("GivenName: %s\n", indidata->givenName);
                     //printf("Surname: %s\n", indidata->surname);
                }
                else{
                    fielddata = create_Field();
                    //((Field*)getFromBack(indidata->otherFields))->tag = p;
                    strcpy(fielddata->tag, p);
                    char * value = malloc(sizeof(char)*50);
                    p = strtok(NULL, " ");
					
					strcpy(value, " ");
                    while(p != NULL){
						strcat(value, " ");
                        strcat(value, p);
                        p = strtok(NULL, " ");
                    }	
                    
                    removeExtraSpace(value);

                    strcpy(fielddata->value, value);
                    insertBack(&indidata->otherFields, fielddata);
                    
                    //printf("Tag: ||%s|| and Value: ||%s||\n", ((Field*)getFromBack(indidata->otherFields))->tag, ((Field*)getFromBack(indidata->otherFields))->value);
                }
            }
            p = strtok(NULL, " ");
        }
        (*counter)++;
    }

    insertBack(&object->individuals, indidata);

    
    (*counter)--;
    return okay;
}


GEDCOMerror familyValidation(char** array, int *counter, int *famflag, GEDCOMobject **obj){

    GEDCOMerror okay;
    okay.type = (ErrorCode)OK;
    okay.line = -1;

    GEDCOMerror invalidrecord;
    invalidrecord.type = (ErrorCode)INV_RECORD;
    invalidrecord.line = -1;

    int prevlvl = 1;
    int currlvl = 1;
    char *string = malloc(sizeof(char)*255);
    //int x = 0, y = 0, z = 0, a = 0;

    while(array[*counter][0] != '0'){

        strcpy(string, array[*counter]);
        char *p = strtok(string, " ");
        
        prevlvl = currlvl;
        currlvl = atoi(p);
        
        if((currlvl == (prevlvl + 1) || currlvl == prevlvl || currlvl == (prevlvl - 1)) && (currlvl < 99)){
            
        }
        else{   
            *famflag = 2;
            (*counter)++;
            *obj = NULL;
            obj = NULL;
            invalidrecord.line = *counter;
            return invalidrecord;
        }

        (*counter)++;
    }

    (*counter)--;
    *famflag = 1;
    return okay;
}


GEDCOMerror family_Parser(char** array, int *counter, GEDCOMobject* object, Family *famdata, Xlist *list){
    
    GEDCOMerror okay;
    okay.type = (ErrorCode)OK;
    okay.line = -1;

    Event *eventdata;
    Field *fielddata;

    char * eventTags [] = { "ADOP", "BIRT", "BAPM", "BARM", "BASM", "BLES", "BURI",
    "CENS", "CHR" , "CHRA", "CONF", "CREM", "DEAT", "EMIG", "FCOM", "GRAD", "IMMI",
    "NATU", "ORDN", "RETI", "PROB", "WILL", "EVEN" , "MARR", "ANUL", "CENS", 
    "DIV", "DIVF", "ENGA", "MARB", "MARC", "MARL", "MARS", "EVEN"};

    int eventlen = sizeof(eventTags)/sizeof(eventTags[0]);

    char *string = malloc(sizeof(char)*255);
    while(array[*counter][0] != '0'){
        
        strcpy(string, array[*counter]);
        char *p = strtok(string, " ");
        p = strtok(NULL, " ");

        while(p != NULL){
            if(eventchecker(p) == true){
                for(int v = 0; v < eventlen; ++v){
                    if(strcmp(p, eventTags[v]) == 0){ 
                        eventdata = create_Event();
                        insertBack(&famdata->events, eventdata);
                        strcpy(((Event*)getFromBack(famdata->events))->type, p);
                        //printf("Event Tag: %s\n", ((Event*)getFromBack(famdata->events))->type);
                    }
                }
                (*counter)++;
                while(array[*counter][0] != '1'){
                    strcpy(string, array[*counter]);
                    char *p = strtok(string, " ");
                    
                    if(strcmp(p, "0") == 0){
						break;
					}
					
                    p = strtok(NULL, " ");
                   

                    while(p != NULL){
						
						
                        if(strcmp(p, "DATE") == 0){
                            p = strtok(NULL, " ");
                            char * date = (char *) malloc(sizeof(char) * 100);
                            
                            strcpy(date, " ");
                            while(p != NULL){
                                strcat(date, " ");
                                strcat(date, p);
                                p = strtok(NULL, " ");
                            }

                            removeExtraSpace(date);

                            ((Event*)getFromBack(famdata->events))->date = date;
                            //printf("Date: ||%s||\n", ((Event*)getFromBack(famdata->events))->date);
                        }
                        else if(strcmp(p, "PLAC") == 0){
                            p = strtok(NULL, " ");
                            char * place = (char *) malloc(sizeof(char) * 100);
                            
                            strcpy(place, " ");
                            while(p != NULL){
                                strcat(place, " ");
                                strcat(place, p);
                                p = strtok(NULL, " ");
                            }

                            removeExtraSpace(place);

                            ((Event*)getFromBack(famdata->events))->place = place;
                            //printf("Place: ||%s||\n", ((Event*)getFromBack(famdata->events))->place);
                        }
                        else{
                            fielddata = create_Field();
                            insertBack(&eventdata->otherFields, fielddata);
                            ((Field*)getFromBack(eventdata->otherFields))->tag = p;
                            char * value = malloc(sizeof(char*)*50);
                            p = strtok(NULL, " ");

							strcpy(value, " ");
                            while(p != NULL){
                                strcat(value, " ");
                                strcat(value, p);
                                p = strtok(NULL, " ");
                            }
                            
                            removeExtraSpace(value);

                            ((Field*)getFromBack(eventdata->otherFields))->value = value;
                            //printf("Tag: %s and Value: %s\n", ((Field*)getFromBack(eventdata->otherFields))->tag, ((Field*)getFromBack(eventdata->otherFields))->value);
                        }
                        p = strtok(NULL, " ");
                    }
                    (*counter)++;
                }
                (*counter)--;
            }
            else if(strcmp(p, "HUSB") == 0){

                Famxref *fam = createFXref();
                
                char *tagstring = malloc(sizeof(char*)*50);
                strcpy(tagstring, p);

                strcpy(fam->tag, tagstring);
                p = strtok(NULL, " ");
                
                //char *refstring = malloc(sizeof(char*)*50);
                //strcpy(refstring, p);

                strcpy(fam->ref, p);

                fam->fam = famdata;

                insertBack(&list->Fxlist, fam);
                
            }
            else if(strcmp(p, "WIFE") == 0){
                
                Famxref *fam = createFXref();

                char *tagstring = malloc(sizeof(char*)*50);
                strcpy(tagstring, p);

                strcpy(fam->tag, tagstring);

                p = strtok(NULL, " ");

                //char *refstring = malloc(sizeof(char*)*50);
                //strcpy(refstring, p);

                strcpy(fam->ref, p);

                fam->fam = famdata;

                insertBack(&list->Fxlist, fam);

            }
            else if(strcmp(p, "CHIL") == 0){

                Famxref *fam = createFXref();
                
                char *tagstring = malloc(sizeof(char*)*50);
                strcpy(tagstring, p);

                strcpy(fam->tag, tagstring);

                p = strtok(NULL, " ");

                //char *refstring = malloc(sizeof(char*)*50);
                //strcpy(refstring, p);

                strcpy(fam->ref, p);

                fam->fam = famdata;

                insertBack(&list->Fxlist, fam);
            }
            else{
                fielddata = create_Field();
                //((Field*)getFromBack(indidata->otherFields))->tag = p;
                strcpy(fielddata->tag, p);
                char * value = malloc(sizeof(char)*50);
                p = strtok(NULL, " ");
					
				strcpy(value, " ");
                while(p != NULL){
					strcat(value, " ");
                    strcat(value, p);
                    p = strtok(NULL, " ");
                }
                
                removeExtraSpace(value);

                strcpy(fielddata->value, value);
                insertBack(&famdata->otherFields, fielddata);
                //printf("Tag: %s and Value: %s\n", ((Field*)getFromBack(famdata->otherFields))->tag, ((Field*)getFromBack(famdata->otherFields))->value);
            }
            p = strtok(NULL, " ");
        }
        (*counter)++;
    }

    insertBack(&object->families, famdata);
    (*counter)--;
    return okay;
}


GEDCOMerror submitterValidation(char** array, int *counter, int *subflag, GEDCOMobject **obj){

    GEDCOMerror okay;
    okay.type = (ErrorCode)OK;
    okay.line = -1;

    GEDCOMerror invalidrecord;
    invalidrecord.type = (ErrorCode)INV_RECORD;
    invalidrecord.line = -1;

    int prevlvl = 1;
    int currlvl = 1;
    char *string = malloc(sizeof(char)*255);

    while(array[*counter][0] != '0'){

        strcpy(string, array[*counter]);
        char *p = strtok(string, " ");
        
        prevlvl = currlvl;
        currlvl = atoi(p);
        
        if((currlvl == (prevlvl + 1) || currlvl == prevlvl || currlvl == (prevlvl - 1)) && (currlvl < 99)){
            
        }
        else{   
            *subflag = 2;
            (*counter)++;
            *obj = NULL;
            obj = NULL;
            invalidrecord.line = *counter;
            return invalidrecord;
        }

        (*counter)++;
    }

    (*counter)--;
    *subflag = 1;
    return okay;
}

GEDCOMerror submitter_Parser(char** array, int *counter, GEDCOMobject* object){
    
    GEDCOMerror okay;
    okay.type = (ErrorCode)OK;
    okay.line = -1;

    object->submitter = object->header->submitter;

    Field *fielddata;

    char *string = malloc(sizeof(char)*255);

    while(array[*counter][0] != '0'){
        
        strcpy(string, array[*counter]);
        char *p = strtok(string, " ");
        p = strtok(NULL, " ");

        while(p != NULL){
            if(strcmp(p, "NAME") == 0){
                p = strtok(NULL, " ");
                char * name = malloc(sizeof(char*)*50);
                name = findValue(p);
                strcpy(object->submitter->submitterName, name);
                //printf("The Submitter Name is: %s\n", object->submitter->submitterName);
            }
            else{
                fielddata = create_Field();
                insertBack(&object->submitter->otherFields, fielddata);
                ((Field*)getFromBack(object->submitter->otherFields))->tag = p;
                char * value = malloc(sizeof(char*)*50);
                p = strtok(NULL, " ");
				
				strcpy(value, " ");
                while(p != NULL){
					strcat(value, " ");
                    strcat(value, p);
                    p = strtok(NULL, " ");
                }

				removeExtraSpace(value);
				
                ((Field*)getFromBack(object->submitter->otherFields))->value = value;
                //printf("Tag: %s and Value: %s\n", ((Field*)getFromBack(object->submitter->otherFields))->tag, ((Field*)getFromBack(object->submitter->otherFields))->value);
            
            }
            p = strtok(NULL, " ");
        }
        (*counter)++;
    }

    (*counter)--;
    return okay;
}

