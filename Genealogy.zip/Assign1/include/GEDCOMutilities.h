#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include "GEDCOMparser.h"
#include "LinkedListAPI.h"


typedef struct{

    char* ref;
    Individual* indi;

} Indixref;

typedef struct{

    char* tag;
    char* ref;
    Family* fam;

} Famxref;

typedef struct{

    List    Ixlist;

    List    Fxlist;

} Xlist;


Individual *create_Individual();
GEDCOMobject *create_Obj();
Field *create_Field();
Family *create_Family();
Header *create_Header();
Event *create_Event();
Submitter *create_Submitter();

void *removeExtraSpace(char *string);

bool eventchecker(char *string);

char *findValue(char *string);

char *Pfgets(char *dst, int max, FILE *fp);