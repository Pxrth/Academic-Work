#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>

#include "GEDCOMparser.h"
#include "GEDCOMutilities.h"


void *removeExtraSpace(char *string){

    int index = 0; 
    int i = 0;

    while(string[index] == '\t' || string[index] == '\n' || string[index] == ' ')  {
        index++;
    }

    if(index != 0){
        i = 0;
        while(string[i + index] != '\0'){
            string[i] = string[i + index];
            i++;
        }
        string[i] = '\0';
    }
    return string;
}

bool eventchecker(char *string){

    char * eventTags [] = { "ADOP", "BIRT", "BAPM", "BARM", "BASM", "BLES", "BURI",
    "CENS", "CHR" , "CHRA", "CONF", "CREM", "DEAT", "EMIG", "FCOM", "GRAD", "IMMI",
    "NATU", "ORDN", "RETI", "PROB", "WILL", "EVEN" , "MARR", "ANUL", "CENS", 
    "DIV", "DIVF", "ENGA", "MARB", "MARC", "MARL", "MARS", "EVEN"};

    int eventlen = sizeof(eventTags)/sizeof(eventTags[0]);

    for(int v = 0; v < eventlen; ++v){
        if(strcmp(string, eventTags[v]) == 0){ 
            return true;
        }
    }

    return false;
}

char *findValue(char *string){

    char *tempstring = malloc(sizeof(char)*255);

    strcpy(tempstring, "");

    if(string != NULL){
        strcat(tempstring, string);
    }


    return tempstring;
}

char *Pfgets(char *dst, int max, FILE *fp){
	int c;
    int a;
	char *p;
    long int pi = 0;

	for (p = dst, max--; max > 0; max--) {
		if ((c = fgetc (fp)) == EOF)
			break;
		*p++ = c;

        pi = ftell(fp);
        a = fgetc(fp);

        if(a == EOF){
            break;
        }

		if (c == '\r' && a != '\n'){
            fseek(fp, pi, SEEK_SET);
            break;
        }
        else if (c == '\n' && a != '\r'){
            fseek(fp, pi, SEEK_SET);
            break;
        }

        fseek(fp, pi, SEEK_SET);

	}
	*p = 0;
	if (p == dst || c == EOF)
		return NULL;
	return (p);
}


char *WriteHeader(const GEDCOMobject* obj){
	
	
	char *string = malloc(sizeof(char) * 500);
	
	char *version = malloc(sizeof(char) * 10);
	sprintf(version, "%f", obj->header->gedcVersion);
	
	char *encoding = malloc(sizeof(char) * 10);
	sprintf(encoding, "%u", obj->header->encoding);

	
	strcpy(string, "1 SOUR ");
	strcat(string, obj->header->source);
	strcat(string, "\n");
	strcat(string, "1 GEDC\n");
	strcat(string, "2 VERS ");
	strcat(string, version);
	strcat(string, "\n");
	strcat(string, "2 FORM LINEAGE-LINKED\n");
	strcat(string, "1 CHAR ");
	
	if(strcmp(encoding, "0") == 0){
		strcat(string, "ANSEL");
	}
	else if(strcmp(encoding, "1") == 0){
		strcat(string, "UTF-8");
	}
	else if(strcmp(encoding, "2") == 0){
		strcat(string, "UNICODE");
	}
	else if(strcmp(encoding, "3") == 0){
		strcat(string, "ASCII");
	}
	
	strcat(string, "\n");
	strcat(string, "1 SUBM @SUB1@\n");
	
	
	
	
	return string;
	
}


char *WriteSubmitter(const GEDCOMobject* obj){
	
	
	char *string = malloc(sizeof(char) *500);
	
	strcpy(string, "0 @SUB1@ SUBM\n");
	strcat(string, "1 NAME ");
	strcat(string, obj->submitter->submitterName);
	strcat(string, "\n");
		
		
	
	return string;	
	
}


char *WriteRecord(const GEDCOMobject* obj){
	
	
	int I = 0;
	int F = 0;
	int C = 1;
	int FC = 1;
	int famCount = getLength(obj->families);
	int indiCount = getLength(obj->individuals);
	
	Xlist *list = createXlist();
	
	char *famXref = malloc(sizeof(char) * 500);
	char *famid = malloc(sizeof(char) * 10);
	
	char *indiXref = malloc(sizeof(char) * 500);
	char *id = malloc(sizeof(char) * 10);

	
	while(FC <= famCount){
		
		Node *family = obj->families.head;
		Family* famdata = NULL;
		
		F = 0;
		
		while(family != NULL){
			
			F++;
			
			if(F == FC){
				famdata = family->data;
				break;
			}
			
			family = family->next;
		}
		
		
		Famxref *famList = createFXref();
		
		sprintf(famid, "%d", FC);
		
		if(FC > 9){
			
			strcpy(famXref, "@F0");
			strcat(famXref, famid);
			strcat(famXref, "@");
			
			strcpy(famList->ref, famXref);
			
			famList->fam = famdata;
			insertBack(&list->Fxlist, famList);
			
		}
		else{
			
			strcpy(famXref, "@F00");
			strcat(famXref, famid);
			strcat(famXref, "@");
			
			strcpy(famList->ref, famXref);
			
			famList->fam = famdata;
			insertBack(&list->Fxlist, famList);
		}
		
		
		FC++;
	}
	
	while(C <= indiCount){
		
		Node *individual = obj->individuals.head;
		Individual* indidata = individual->data;
		Indixref *indiList = createIXref();
		
		I = 0;
		while(individual != NULL){
			
			I++;
			
			if(I == C){
				indidata = individual->data;
				break;
			}
			
			individual = individual->next;
		}
		
				
		sprintf(id, "%d", C);
		
		if(C > 9){
			strcpy(indiXref, "@I0");
			strcat(indiXref, id);
			strcat(indiXref, "@");
			
			strcpy(indiList->ref, indiXref);
			
			indiList->indi = indidata;
			insertBack(&list->Ixlist, indiList);
			
		}
		else{
			strcpy(indiXref, "@I00");
			strcat(indiXref, id);
			strcat(indiXref, "@");
			
			strcpy(indiList->ref, indiXref);
			
			indiList->indi = indidata;
			insertBack(&list->Ixlist, indiList);
		}
		
		C++;
	}
	
	
	char *string = malloc(sizeof(char) * 100000);

	
	Node *temp = list->Ixlist.head;
	
	Node *famtemp = list->Fxlist.head;
	Node *childloop2 = ((Famxref*)famtemp->data)->fam->children.head;
	

	strcpy(string, " ");
	
	while(temp != NULL){
	
		Individual* Indi = ((Indixref*)temp->data)->indi;
		Node *field = Indi->otherFields.head;
		Node *event = Indi->events.head;
		
		strcat(string, "0 ");
		strcat(string, ((Indixref*)temp->data)->ref);
		strcat(string, " INDI\n");
		strcat(string, "1 NAME ");
		strcat(string, Indi->givenName);
		strcat(string, " ");
		strcat(string, "/");
		
		if(strcmp(Indi->surname, " ") == 0){
			strcat(string, "/\n");
		}
		else{
			strcat(string, Indi->surname);
			strcat(string, "/\n");
		}
		
		while(field != NULL){
			
			Field* temp2 = ((Field*)field->data);
			if(strcmp(temp2->tag, "GIVN") == 0){
				
				strcat(string, "2 GIVN ");
				strcat(string, temp2->value);
				strcat(string, "\n");
			}
			else if(strcmp(temp2->tag, "SURN") == 0){
				
				strcat(string, "2 SURN ");
				strcat(string, temp2->value);
				strcat(string, "\n");
			}
			else{
				strcat(string, "1 ");
				strcat(string, temp2->tag);
				strcat(string, " ");
				strcat(string, temp2->value);
				strcat(string, "\n");
				
			}
			
			field = field->next;
		}
		
		
		while(event != NULL){
			
			Event* temp3 = ((Event*)event->data);
			
			strcat(string, "1 ");
			strcat(string, temp3->type);
			strcat(string, "\n");
			
			if(temp3->date != NULL && strcmp(temp3->date, " ") != 0){
				strcat(string, "2 DATE ");
				strcat(string, temp3->date);
				strcat(string, "\n");
			}
			
			if(temp3->place != NULL && strcmp(temp3->place, " ") != 0){
				strcat(string, "2 PLAC ");
				strcat(string, temp3->place);
				strcat(string, "\n");
			}
			
			event = event->next;
		}
		
		famtemp = list->Fxlist.head;
		
		while(famtemp != NULL){
			
			if(((Famxref*)famtemp->data)->fam->husband == Indi){
				
				strcat(string, "1 FAMS ");
				strcat(string, ((Famxref*)famtemp->data)->ref);
				strcat(string, "\n");
				
			}
			else if(((Famxref*)famtemp->data)->fam->wife == Indi){
				
				strcat(string, "1 FAMS ");
				strcat(string, ((Famxref*)famtemp->data)->ref);
				strcat(string, "\n");
				
			}	
			
			famtemp = famtemp->next;
		}
		
		
		famtemp = list->Fxlist.head;
		
		while(famtemp != NULL){
		
			childloop2 = ((Famxref*)famtemp->data)->fam->children.head;
		
			while(childloop2 != NULL){
				
				if(childloop2->data == Indi){
					
					strcat(string, "1 FAMC ");
					strcat(string, ((Famxref*)famtemp->data)->ref);
					strcat(string, "\n");
					
				}
				
				childloop2 = childloop2->next;
			}
		
			famtemp = famtemp->next;
		}
		
		temp = temp->next;
	}
	
	
	
	
	
	Node *tempF = list->Fxlist.head;
	Node *loopfam = obj->families.head;
	Node *loopindi = list->Ixlist.head;
	Node *childloop = ((Family*)loopfam->data)->children.head;
	
	while(loopfam != NULL){
		
		Family* Fam = (Family*)loopfam->data;
		Node *event = Fam->events.head;
		
		strcat(string, "0 ");
		strcat(string, ((Famxref*)tempF->data)->ref);
		strcat(string, " FAM\n");
		

		loopindi = list->Ixlist.head;
		
		while(loopindi != NULL){
			
			
			if(((Family*)loopfam->data)->husband == ((Indixref*)loopindi->data)->indi){
				
				strcat(string, "1 HUSB ");
				strcat(string, ((Indixref*)loopindi->data)->ref);
				strcat(string, "\n");
				
			}
			else if(((Family*)loopfam->data)->wife == ((Indixref*)loopindi->data)->indi){
				
				strcat(string, "1 WIFE ");
				strcat(string, ((Indixref*)loopindi->data)->ref);
				strcat(string, "\n");
			}	
		
			loopindi = loopindi->next;
		}
		
		while(event != NULL){
			
			Event* tempF2 = ((Event*)event->data);
			
			
			strcat(string, "1 ");
			strcat(string, tempF2->type);
			strcat(string, "\n");
			
			if(tempF2->date != NULL && strcmp(tempF2->date, " ") != 0){
				strcat(string, "2 DATE ");
				strcat(string, tempF2->date);
				strcat(string, "\n");
			}
			
			if(tempF2->place != NULL && strcmp(tempF2->place, " ") != 0){
				strcat(string, "2 PLAC ");
				strcat(string, tempF2->place);
				strcat(string, "\n");
			}
			
			
			event = event->next;
		}
			
		
		loopindi = list->Ixlist.head;
		
		while(loopindi != NULL){
		
			childloop = ((Family*)loopfam->data)->children.head;
		
			while(childloop != NULL){
				
				if(childloop->data == ((Indixref*)loopindi->data)->indi){
					
					strcat(string, "1 CHIL ");
					strcat(string, ((Indixref*)loopindi->data)->ref);
					strcat(string, "\n");
					
				}
				
				childloop = childloop->next;
			}
		
		
			loopindi = loopindi->next;
		}
		
		tempF = tempF->next;
		
		
		loopfam = loopfam->next;
	}
	
	
	
	removeExtraSpace(string);

	
	return string;
	
}
